#include "pch.h"
#include "ReporteAmbiental.h"

void RobotMineroModel::ReporteAmbiental::MostrarConcetraciones()
{
    throw gcnew System::NotImplementedException();
}

void RobotMineroModel::ReporteAmbiental::MostrarTemperatura()
{
    throw gcnew System::NotImplementedException();
}
