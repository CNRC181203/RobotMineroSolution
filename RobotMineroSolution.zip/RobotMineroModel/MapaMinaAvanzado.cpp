#include "pch.h"
#include "MapaMinaAvanzado.h"

void RobotMineroModel::MapaMinaAvanzado::GenerarMapaAvanzado()
{
    throw gcnew System::NotImplementedException();
}
