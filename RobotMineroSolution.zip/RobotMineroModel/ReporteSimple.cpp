#include "pch.h"
#include "ReporteSimple.h"
