#include "pch.h"
#include "SensorTemperatura.h"

double RobotMineroModel::SensorTemperatura::MedirTemperatura()
{
    return 0.0;
}
