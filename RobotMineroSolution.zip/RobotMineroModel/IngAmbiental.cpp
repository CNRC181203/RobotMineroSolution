#include "pch.h"
#include "IngAmbiental.h"

void RobotMineroModel::IngAmbiental::VisualizarConcetracion()
{
    throw gcnew System::NotImplementedException();
}
