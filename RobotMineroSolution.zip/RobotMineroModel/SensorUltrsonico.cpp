#include "pch.h"
#include "SensorUltrsonico.h"

double RobotMineroModel::SensorUltrsonico::MedirDistancia()
{
    return 0.0;
}
