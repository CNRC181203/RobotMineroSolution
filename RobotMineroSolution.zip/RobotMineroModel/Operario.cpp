#include "pch.h"
#include "Operario.h"

void RobotMineroModel::Operario::IniciarAnalisis()
{
    throw gcnew System::NotImplementedException();
}

void RobotMineroModel::Operario::VisualizarReporteSimple()
{
    throw gcnew System::NotImplementedException();
}
