#pragma once
using namespace System;

namespace RobotMineroModel {
	public ref class Reporte
	{
		DateTime^ Fecha;
		String^ Hora;//

	};
}
