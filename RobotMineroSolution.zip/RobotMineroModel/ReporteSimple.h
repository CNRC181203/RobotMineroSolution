#pragma once
#include"Reporte.h"

namespace RobotMineroModel {
	public ref class ReporteSimple:public Reporte
	{
	public:
		double TiempoOperacion;
	};
}