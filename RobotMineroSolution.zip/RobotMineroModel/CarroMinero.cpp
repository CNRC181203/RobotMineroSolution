#include "pch.h"
#include "CarroMinero.h"

void RobotMineroModel::CarroMinero::Mover()
{
    throw gcnew System::NotImplementedException();
}

void RobotMineroModel::CarroMinero::Sensar()
{
    throw gcnew System::NotImplementedException();
}
