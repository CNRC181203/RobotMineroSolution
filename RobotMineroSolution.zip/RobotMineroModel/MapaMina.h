#pragma once

namespace RobotMineroModel {
	public ref class MapaMina
	{
	private:
		double CoordenadaX;
		double CoordenadaY;
	public:
		void GenerarMapa();

	};
}
//Falta la parte matematica del calculon de X e Y, capaz con un metodo 