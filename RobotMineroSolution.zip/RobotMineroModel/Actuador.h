#pragma once

namespace RobotMineroModel {
	public ref class Actuador
	{
	public:
		int Id;
		int NumeroSerio;
		bool Estado;
	};
}
