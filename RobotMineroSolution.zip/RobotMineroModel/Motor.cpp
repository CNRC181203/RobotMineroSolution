#include "pch.h"
#include "Motor.h"

void RobotMineroModel::Motor::CalcularRpm()
{
    throw gcnew System::NotImplementedException();
}
