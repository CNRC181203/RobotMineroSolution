#include "pch.h"
#include "MapaMina.h"

void RobotMineroModel::MapaMina::GenerarMapa()
{
    throw gcnew System::NotImplementedException();
}
