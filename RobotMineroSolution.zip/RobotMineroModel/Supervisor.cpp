#include "pch.h"
#include "Supervisor.h"

void RobotMineroModel::Supervisor::VisualizarMapaAvanzado()
{
    throw gcnew System::NotImplementedException();
}
