#pragma once
using namespace System;

namespace RobotMineroModel {
	public ref class Sensor
	{
	public:
		int Id;
		String^ NumeroSerie;
	};
}
