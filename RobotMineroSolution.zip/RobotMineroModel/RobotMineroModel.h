#pragma once

using namespace System;

namespace RobotMineroModel {
	public ref class Class1
	{
		// TODO: Agregue aquí los métodos de esta clase.
	};
}
