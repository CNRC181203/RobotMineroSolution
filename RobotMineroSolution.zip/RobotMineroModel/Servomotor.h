#pragma once

namespace RobotMineroModel {
	public ref class Servomotor
	{
	public: 
		double angulo;
	};
}
//