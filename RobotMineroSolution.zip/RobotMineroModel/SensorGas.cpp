#include "pch.h"
#include "SensorGas.h"

double RobotMineroModel::SensorGas::MedirHumo()
{
    return 0.0;
}

double RobotMineroModel::SensorGas::MedirMetano()
{
    return 0.0;
}

double RobotMineroModel::SensorGas::MedirMonoxido()
{
    return 0.0;
}

double RobotMineroModel::SensorGas::MedirAmoniaco()
{
    return 0.0;
}
